from pymos import *
plano = Plano()
curva1 = Curve(plano,"x**2",-5,5,50)
curva2 = Curve(plano,"x**5",-2,2,30)
plano.show()
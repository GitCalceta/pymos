import matplotlib.pyplot as plt

class Curve2D():
    def __init__(self,plano,expr,start,end,res):
        self.expr = expr
        self.start = start
        self.end = end
        self.res = res
        plano.add_curve(self)
    def points(self):
        delta_x = (abs(self.end-self.start))/self.res
        lista_puntos_x = []
        lista_puntos_y = []
        for i in range(self.res+1):
            x = (i*delta_x)+self.start
            lista_puntos_x.append(x)
            lista_puntos_y.append(self.expr_eval(dependant = x))
        return [lista_puntos_x,lista_puntos_y]
        
    def expr_eval(self,**kwargs):
        return eval(self.expr)

